Group Members - Joey Gallichio, Evan Boyd, Jake Morgan, Pablo Lasarte

Project Description - Our project is aiming and managing a restaurant by developing a comprehensive digital solution that compresses the management together. It includes menu management, order processing, table reservation, inventory management, customer loyalty programs and employee scheduling. By integrating the essential components into a single system, we are able to enhance customer experience and optimize resource utilization for restaurant owners and staff
