package Models;

public class Schedule {

}
