package Enums;

public enum MenuCategory {
    APPETIZERS,
    MAIN,
    DESSERTS
}
