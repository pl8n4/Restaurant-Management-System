package Enums;

public enum OrderStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
